# Exact-byte recovery challenge

Recover the original bytes of each supplied file. Record your available inputs, methods, time and result. Submit bytes, not merely plausible prose. An evaluator can release additional information after you freeze each attempt.

For a genuinely independent first attempt, use a fresh context for each file and receive only that file.
