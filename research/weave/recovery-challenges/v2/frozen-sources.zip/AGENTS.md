# stack agent guide

This repository is `The-Interdependency/stack`, the organization's composition forge:
canonical projects are pinned here, stack-local research can combine them, and emergent
projects may later graduate into their own repositories.

## Authority and topology

- `libs/<repo>/` is the manifest-pinned canonical repository view. Treat it as read-only
  inside stack; canonical edits happen in the owning repository.
- `research/<repo>/` is current stack-local research against an exact pinned base. It is
  not canon merely because it is in stack.
- `research/english-gonol/` is a distinct stack-local English lexical/gonol construction
  component. UCNS owns consumed geometry; EDCM may evaluate outputs but does not define
  the English Gonol construction. Its `FULL_VIEW_AUDIT.json` and
  `docs/hyperspace-views-full-v1.md` bind a complete 164,864-word four-view census;
  address metadata and independent information contribution do not establish inference quality.
- `research/python-gonol/` is a distinct stack-local Python source/gonol construction
  component. It owns Python source admission and bottom-up affixiation only; METAPAT owns
  affixiation semantics, UCNS owns consumed geometry, and parser objects are witnesses
  rather than gonol identities.
- `research/urpcs/` is retired historical evidence. GPT-assisted implementation
  substituted a recursive pairing/authenticated codec for Erin Spencer's intended
  multi-arity interleaving construction. Do not extend it or treat any passing test,
  vector, decoder audit, or measurement as evidence for the intended URPCS design.
- `research/weave/` owns new Stack-local research into the full intended encryption system. Preserve all declared layers: hyperspace/gonol plaintext construction, private-gonol recovery, multiple reconstruction-dependent threads, thread-associated corpus/material, multi-arity last/first interleaving, and the intended asymmetric public/private relation. Read `SPECIFICATION.md` before implementation. Unresolved mechanics must fail closed as `hmmm`; do not reduce the project to its interleave layer or substitute a familiar cipher, codec, permutation generator, or URPCS mechanism.
- `research/pi-radix/` owns bounded Stack-local computations over radix
  representations of pi. It may report exact digit streams, decoded prime blocks,
  terminal-gcd sieves and derived unit-circle coordinates. It does not own general
  prime-number canon, transfer METAPAT or UCNS authority, establish pi normality,
  or promote cross-base recurrence into a base-independent law.
- `research/psfr/` is Psychosocial Fauna Research (PSFR), a stack-local pre-graduation
  research area. It preserves two non-collapsed tracks: host-transcendent pattern-lineage
  ecology and agency-displacement phenomenology. Preserve first-person/witness event
  distinctions before causal compression; do not infer external-agent ontology from
  automatic action, lost time, or a physiological correlate alone.
- `research/zfae/` owns Stack-local inference-construction experiments. ZFAE
  retains conceptual authority, PTCNA owns neural construction, and a0 owns
  runtime integration. Keep a0-betatest comparisons separately attributed.
  Read its README and BASE before work; retain the current PTCNA neural-audit
  prerequisite and the incomplete UCHC release/reconsumption boundary.
  Its input parser consumes the exact English GlyphGonol producer and UCNS
  carrier declared in GONOL_PARSER.json. Preserve occurrences and missing
  admission; parser completion is not neural or higher-gonol completion.
- `research/a0-municipality/` owns the municipal application specification and
  cross-project integration research. Read its README for current placement,
  then preserve the complete v1.1 HANDOFF.md and its source receipt. a0 owns
  runtime implementation; UCNS and current Stack/UCHC owners retain construction
  authority. Keep all four workflows, the reserved fifth, homeless-union
  stewardship, tax-funded remuneration and native origin requirements. Placement
  is not a working app, partner authorization or operational proof.
- `integration/epac/` consumes the hash-pinned public EPAC release.
  `research/epac/` retains historical evidence only; route implementation changes to
  `The-Interdependency/epac`. Do not restore the retired forge import path.
- root-level emerging projects such as `ahbg/` may be close to external repo-hood; root
  placement does not transfer authority from their inputs.
- `STACK_MANIFEST.md` and `stack-manifest.json` own stack-level participant provenance.
- `backend/` is the durable stack orchestration/fresh-making control plane.
- `frontend/cli/` is the replaceable human/operator surface for that backend.
- `skill-lib/` is the currently pinned operational skill snapshot; exact newer doctrine
  may be bound separately only when its provenance and non-transfer boundary are explicit.

## Structural update gate

Before adding, moving, separating, extracting, graduating, renaming, removing, or
changing the authority/relation/pin of a stack participant or research workspace, load:

```text
.agents/skills/stack-update/SKILL.md
```

Also resolve the applicable `interdependent-work-graph` doctrine and, for lifecycle
transitions, `project-incubation-graduation`. Structural changes are one transaction:
update every affected machine/human authority projection, remove superseded ownership
claims, recompute the work-graph digest, and pass:

```bash
python tools/check_stack_consistency.py
```

Do not treat moved code, passing local tests, or a new repository as sufficient evidence
that stack authority/provenance records are current.

## Fresh-making boundary

PostgreSQL on the VM is the single production state authority for derivation specs,
freshness keys, logical jobs, attempts/leases, receipts, target acceptance, dependency
edges, and `hmmm`. It is **not** authority for repository source, canon, generated
artifact meaning, theorem status, measurement validity, or publication standing.

```text
fresh != recent
fresh == exact current identities + matching accepted receipt + output digest + verifier
```

MSDMD collection regeneration is the first derivation adapter. The old `stackctl msdmd`
namespace is deprecated and removed; use `stackctl fresh ...`.

## Boundaries

- Do not edit `libs/` as doctrine or silently update pinned source commits.
- Do not transfer semantic, proof, empirical, certification, measurement, or license
  status between participant repositories.
- Do not call generated output fresh from timestamps, executor success, or GitHub Actions
  status alone.
- GitHub Actions may become an executor but must not become durable state or acceptance
  authority.
- Generated local state, caches, candidates, backups, and receipt projections must not be
  committed unless the artifact is explicitly repository-owned evidence.
- For behavior-bearing build changes, resolve and follow applicable `skill-lib` doctrine;
  `backend/fresh-making-provenance.json` binds the current runtime's exact fresh-making
  doctrine identity.

## Checks

Structural stack consistency:

```bash
python tools/check_stack_consistency.py
```

EPAC release integration (new output directory outside Stack):

```bash
python3 integration/epac/reconsume.py \
  integration/epac/release-lock.json /tmp/epac-public-consumption python3.12
```

Fresh-making/backend checks that can run without PostgreSQL:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -W error::ResourceWarning -m unittest \
  backend.tests.test_orchestrator \
  backend.tests.test_worker_postgres \
  backend.tests.test_publication_rollback
python3 -m compileall -q backend frontend
bash -n backend/ops/backup_postgres.sh backend/ops/restore_test.sh
```

PostgreSQL integration checks require an explicitly disposable database. A skipped
integration check is `hmmm`, not a pass.

AHBG/Grok has its own local suites under `ahbg/grok/`; run those when touching that
workspace. The root stack-consistency checker verifies declared authority/provenance
coherence; it does not replace workspace behavioral tests.

## hmmm

- Concrete VM PostgreSQL/auth/service-account/storage and backup-mount acceptance remains
  unobserved until checked on the VM.
- Organization aggregate and website-projection derivation specs are not yet registered.
- English Gonol Construction has distinct stack-local authority but has not yet gained an
  independent repository/release authority boundary.
- Python Gonol Construction has distinct stack-local authority but has not yet gained an
  independent repository/release authority boundary; exact UCNS affixiation geometry is unresolved.
- URPCS is retired for specification divergence. Why GPT substituted the different
  architecture remains `hmmm`; its retained evidence is historical and implementation-local.
- Weave remains research. Its explicit native binary sequence-cycle candidate
  lives in `research/weave/native_binary.py`; UCNS geometry is consumed, not
  redefined. UCHC binary graduation has not occurred. Private/public lifting,
  authentication/state and full-cipher security remain `hmmm`.
- Pi radix research has measured finite cross-base recurrences; the segmentation
  law, if any, that would make a result base-independent remains `hmmm`.
- Project graduation automation remains unimplemented.

URPCS provenance boundary: the immutable public intended-design transcript identity
and detailed design attribution remain unresolved; see
[`SOURCE_RECEIPT.json`](research/urpcs/SOURCE_RECEIPT.json).
